# Week8_skeletoncode_CSC229_Lab
Complete all 4 ToDos and then push your code to your Github and submit the link. For the algorithm analysis as comments in your solution.
